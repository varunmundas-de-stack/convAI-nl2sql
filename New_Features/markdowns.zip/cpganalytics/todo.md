# CPG Analytics — TODO

> Items are added on the "add to todo" command, each stamped with date + time.

---

## Open

_(nothing yet)_

---

## Done

_(nothing yet)_
