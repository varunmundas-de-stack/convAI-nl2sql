# 12 — Metric Registry

> **Status:** DRAFT v0.1 (2026-06-11)
> One place where every metric is defined. Other files only name metrics. This file says
> what each one means and where it comes from.

---

## Purpose

A persona card says `net_sales`. It does not say what that is.
The metric registry answers:

- What is this metric?
- Which Cube.js measure gives its value?
- How do we show it (currency, percent, count)?
- Is going up good or bad?

We define each metric **once** here. Everyone else just uses the id.
This keeps the rule "facts are deterministic" safe: the number always comes from Cube.js,
never from the LLM.

## Design rules

- One metric = one entry = one id.
- The id is stable. Never reuse it for something else.
- Every metric maps to exactly one Cube.js measure.
- No formulas live in cards or rules. They live in Cube.js. This file just points to them.

---

## Field table

| Field | Type | Required | Notes |
|---|---|---|---|
| `metric_id` | string (snake_case) | yes | stable id, e.g. `net_sales` |
| `display_name` | string | yes | label shown to users, e.g. "Net Sales" |
| `cube_measure` | string | yes | the Cube.js measure, e.g. `Sales.netSales` |
| `format` | enum `currency\|percentage\|count\|number` | yes | how to show the value |
| `unit` | enum `value\|units\|days\|pct\|count` | yes | what the number counts |
| `direction` | enum `higher_is_better\|lower_is_better\|neutral` | yes | used by insights to judge good vs bad |
| `description` | string | yes | one plain line: what it means |

---

## JSON Schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://cpg-analytics/spec/metric-registry.schema.json",
  "title": "MetricRegistry",
  "type": "array",
  "items": {
    "type": "object",
    "additionalProperties": false,
    "required": ["metric_id", "display_name", "cube_measure",
                 "format", "unit", "direction", "description"],
    "properties": {
      "metric_id":    { "type": "string", "pattern": "^[a-z][a-z0-9_]*$" },
      "display_name": { "type": "string", "minLength": 1 },
      "cube_measure": { "type": "string", "minLength": 1 },
      "format":       { "enum": ["currency", "percentage", "count", "number"] },
      "unit":         { "enum": ["value", "units", "days", "pct", "count"] },
      "direction":    { "enum": ["higher_is_better", "lower_is_better", "neutral"] },
      "description":  { "type": "string", "minLength": 1 }
    }
  }
}
```

---

## Validation rules (check in CI)

1. Every `metric_id` is unique.
2. Every `cube_measure` must exist in the Cube.js schema.
3. Every metric named in a persona card (`kpis`) must exist here.
4. `format` and `unit` should agree (e.g. `percentage` goes with `unit: pct`).

---

## Versioning

- Add a new metric → fine, no break.
- Rename or remove a metric → breaking. Any card using it must be updated.

---

## Worked example

See `examples/metric-registry.yaml`. A few entries:

```yaml
- metric_id: net_sales
  display_name: "Net Sales"
  cube_measure: Sales.netSales
  format: currency
  unit: value
  direction: higher_is_better
  description: "Primary net sales value after returns and claims."

- metric_id: target_achievement_pct
  display_name: "Target Achievement"
  cube_measure: Sales.targetAchievementPct
  format: percentage
  unit: pct
  direction: higher_is_better
  description: "Net sales as a percent of target for the period."

- metric_id: distributor_stock_days
  display_name: "Stock Days"
  cube_measure: Inventory.distributorStockDays
  format: number
  unit: days
  direction: neutral
  description: "Days of stock cover at the distributor. Too low or too high is a risk."
```
