# 14 — Section Grammar (Home Layout)

> **Status:** DRAFT v0.1 (2026-06-12)
> Describes how a role's home page is laid out. This is the only file about layout.
> It is also common to all roles: same grammar, different sections.

---

## Purpose

The persona card (`10`) says *what* a role cares about (KPIs, insights, questions, actions).
It does not say how the home page is arranged.

This file defines a **home template**: an ordered list of sections.
Each section pulls from the card and from the resolved data.

We keep layout separate from the card on purpose (locked decision). The card is the
meaning. The home template is the arrangement. Both are common across roles.

## Note on visuals

This grammar is about **business structure**, not pixels. No CSS, colour, or widths.
The frontend decides the look. This file only says "show a summary here, insights next".

## Design rules

- A home template targets one `card_id`.
- Sections are ordered. The order is the page order.
- A section either lists explicit metrics, or pulls from the card / engine output.
- It never invents data. It only arranges what `10`, `12`, and `13` produce.

---

## Section types

| type | shows | pulls from |
|---|---|---|
| `summary` | a few headline numbers | explicit metric ids |
| `kpi_strip` | a row of KPIs | explicit metric ids (or card.kpis) |
| `insight_list` | ranked insight cards | card.insight_types + engine ranking |
| `action_list` | recommended actions | the card's `actions` whose `from_insight` matches the top insights (or explicit) |
| `suggested_questions` | Ask-Analyst questions | card.questions (question bank) |
| `chart` | one trend chart | a metric (+ optional `trend_grain`; defaults to the `sales_trend` preference) |

---

## Field table

| Field | Type | Required | Notes |
|---|---|---|---|
| `card_id` | string | yes | which persona this home is for; must exist in `10` |
| `sections` | Section[] | yes | ordered list |
| `sections[].id` | string | yes | stable id |
| `sections[].title` | string | yes | shown as the section heading |
| `sections[].type` | enum (above) | yes | which section kind |
| `sections[].items` | Item[] | summary/kpi_strip | `{label, metric}`; format comes from `12` |
| `sections[].max_items` | integer | list types | cap on rows |
| `sections[].filters` | object | insight_list | e.g. `{priority: [critical, high]}` |
| `sections[].insight_types` | string[] | no | override; default = card.insight_types |
| `sections[].source` | enum `priority_insights\|question_bank` | action_list / suggested_questions | where to pull |
| `sections[].metric` | string | chart | metric id for the chart |
| `sections[].trend_grain` | enum `day\|week\|month` | chart (optional) | overrides the resolved `sales_trend` preference (`11`) |

---

## JSON Schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://cpg-analytics/spec/section-grammar.schema.json",
  "title": "HomeTemplate",
  "type": "object",
  "additionalProperties": false,
  "required": ["card_id", "sections"],
  "properties": {
    "card_id": { "type": "string", "pattern": "^[a-z][a-z0-9_]*$" },
    "sections": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "object",
        "additionalProperties": false,
        "required": ["id", "title", "type"],
        "properties": {
          "id":    { "type": "string" },
          "title": { "type": "string", "minLength": 1 },
          "type":  { "enum": ["summary", "kpi_strip", "insight_list",
                              "action_list", "suggested_questions", "chart"] },
          "items": {
            "type": "array",
            "items": {
              "type": "object",
              "additionalProperties": false,
              "required": ["label", "metric"],
              "properties": {
                "label":  { "type": "string" },
                "metric": { "type": "string" }
              }
            }
          },
          "max_items":     { "type": "integer", "minimum": 1 },
          "filters":       { "type": "object" },
          "insight_types": { "type": "array", "items": { "type": "string" } },
          "source":        { "enum": ["priority_insights", "question_bank"] },
          "metric":        { "type": "string" },
          "trend_grain":   { "enum": ["day", "week", "month"] }
        }
      }
    }
  }
}
```

---

## Validation rules (check in CI)

1. `card_id` exists in the persona card set (`10`).
2. Every `items[].metric` and any `chart` `metric` exists in the metric registry (`12`).
3. Any `insight_types` listed exist in the insight-rule registry (`13`) and are a subset
   of the card's `insight_types`.
4. `summary` / `kpi_strip` sections must have `items`. List sections should have `max_items`.

---

## Worked example

See `examples/nsm.home.yaml`. It rebuilds the National Sales Manager home you sketched:
Today's Business Summary, Top Priority Insights, Recommended Actions, Ask CPG Analyst.
