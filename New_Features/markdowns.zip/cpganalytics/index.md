# CPG Analytics — Master Index

> Maps every step from customer data to deployed experience, with the spec document that governs it.
> Refresh this file whenever scope or spec changes.

_Last updated: 2026-06-29_

---

| Step | Activity | Spec Doc | What We Are Doing |
|------|----------|----------|-------------------|
| 1 | Customer provides raw data | _(outside spec)_ | Receive fact tables + dimension tables (sales hierarchy, product, geography, users) |
| 2 | Build semantic layer on Cube.js | [spec/12](spec/12-metric-registry.md) · [metric-registry.yaml](spec/examples/metric-registry.yaml) | Map fact table columns to named measures. Define every metric the business can compute. RBAC wired here. |
| 3 | Curate persona cards _(vendor IP)_ | [spec/10](spec/10-persona-card.schema.md) · [asm.card.yaml](spec/examples/asm.card.yaml) · [nsm.card.yaml](spec/examples/nsm.card.yaml) | For each role encode job, hierarchy, grain, primary + secondary KPIs, insight types, questions, actions, cold-start slots. |
| 4 | Define preference catalog | [spec/11](spec/11-catalog.schema.md) · [catalog.yaml](spec/examples/catalog.yaml) | Every disambiguation slot (sales type, measure unit, comparison period etc.) mapped to metrics/filters. Role defaults pre-filled. |
| 5 | Define insight rules | [spec/13](spec/13-insight-rule.schema.md) · [insight-rules.yaml](spec/examples/insight-rules.yaml) | Deterministic checks on metrics. Risk, Opportunity, Anomaly, Driver. Thresholds, variance, z-score triggers. |
| 6 | Define home layout | [spec/14](spec/14-section-grammar.schema.md) · [nsm.home.yaml](spec/examples/nsm.home.yaml) | Ordered sections for each role's home page. Summary, KPI strip, insight list, actions, questions, chart. |
| 7 | Tenant onboarding _(customer deploys)_ | [spec/20](spec/20-resolution.md) §1–3 · Tier 2 | Buyer assigns each user to a persona card. Inject their real RBAC scope (region, area, distributor). Override thresholds if needed. |
| 8 | Runtime resolution at login | [spec/20](spec/20-resolution.md) §1–4 · Tiers 1, 2, 3 | At login: load card (Tier 1) + apply tenant binding (Tier 2) + user choices (Tier 3). Resolve all preference slots. |
| 9 | Experience generation _(scheduler runs per user)_ | [spec/00](spec/00-architecture.md) · [spec/20](spec/20-resolution.md) §6–8 | Query Cube.js (RBAC-filtered) → run insight rules → score confidence + priority → attach actions + questions → build home via layout → LLM writes the words → store payload. |
| 10 | User logs in _(render)_ | [spec/14](spec/14-section-grammar.schema.md) · [spec/20](spec/20-resolution.md) §8 | Fetch stored payload. Render 4 stages: Dashboard → Insights → Actions → Chat. |
| 11 | User asks a question _(chat / investigation)_ | [spec/20](spec/20-resolution.md) §4–5 · [spec/10](spec/10-persona-card.schema.md) `job_description` | Scope check (RBAC + job) → curated question fast path OR free-text NLU → Cube.js query → LLM narrates answer. |

---

> **Governing rule across all steps:** Facts are deterministic (Cube.js + SQL). Language is intelligent (LLM narrates only). See [spec/00](spec/00-architecture.md).
