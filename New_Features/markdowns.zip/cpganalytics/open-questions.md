# CPG Analytics — Open Product Questions

> A running list of product/design questions to decide.
> Separate from the spec. These shape what we build, but are not contracts yet.

---

## Q1 — What is the scope of the Assistant? When does it say "Sorry, I can't help"?

_Raised: 2026-06-12 10:47 IST · Status: DECIDED 2026-06-12 (see decision at end)_

The Assistant should not answer everything. We need a clear line.

### Examples the user wants to limit

1. Out-of-syllabus questions (nothing to do with their data).
2. "How do I grow sales in Chennai? Give me some tips." (generic advice)
3. "I want to impress my manager. Give me insight on where we are losing sales,
   or where we can improve." (vague + emotional framing)
4. "Help me prepare for my Quarterly Review with my manager tomorrow." (broad task)

### My view (to discuss — not decided yet)

The line is not "block vague or emotional questions."
The real line is simple:

- **In scope** = anything we can answer from the user's own data, within their access.
- **Out of scope** = anything that needs knowledge or judgement that is not in the data.

So I would use three buckets, not just "yes / no":

```text
1. ANSWER    → it is a data question, within access. Just do it.
2. REDIRECT  → there is a real data question hiding inside. Offer that.
3. REFUSE    → nothing to do with their data. Polite no.
```

How each example maps:

- Example 1 → **REFUSE.** Not about their data.
- Example 2 → **REDIRECT.** No generic tips. But offer: "I can show you where
  Chennai sales dropped, and which distributors and SKUs are weak. Want that?"
- Example 3 → **REDIRECT, then ANSWER.** Drop the "impress my manager" part.
  "Where are we losing sales / where can we improve" IS the core job of this app.
  We should answer it from data. Blocking it would remove our main value.
- Example 4 → **NEEDS A DECISION.** "Prepare for my review" could map to a real
  feature: "summarise my performance this quarter from my data." That is useful.
  Or it could expect coaching, slides, talking points — which are out of scope.

### Always-on guardrails (regardless of bucket)

- Stay inside the user's RBAC scope. Cannot ask about data they cannot see.
- No generic advice that is not grounded in their data.
- No made-up numbers (the core rule).
- No tasks outside analytics (writing emails, making slides) — unless we decide
  a "summary" feature is in scope.

### DECISION — 2026-06-12

**Scope = the persona's JOB DESCRIPTION.** A plain-English write-up, one per role.

Rule: **if the question is part of the job, handle it. If not, decline.**

- These are business users. Ignore emotional framing ("impress my manager",
  "review tomorrow"). Look past the feeling to the real task.
- If that task is in the job description → answer it from data.
- If not → polite decline. Redirect to a data version when one exists.

How the examples resolve:

- Ex 1 (out of syllabus) → DECLINE. Not in any job.
- Ex 2 (generic Chennai tips) → REDIRECT to the data version (where sales dropped).
- Ex 3 (where are we losing sales) → ANSWER. It is the core of the job.
- Ex 4 (prepare for review) → ANSWER the data-summary part. "Manager summary" is
  already an in-scope feature in the cards.

Two fences sit BESIDE the job description, not inside it:

- **RBAC (data access)** stays hard and deterministic. The job description sets the
  TOPIC only, never who-can-see-what.
- **Data availability.** In-topic but no data → say "I don't have that data."

Spec impact: added a `job_description` field to the persona card (file `10`).
Build note for later: pair the job description with a tiny always-refuse /
always-allow list for predictability. This belongs in the future chat/intent design.

---

## Q2 — Geo depth: how deep can a user look?

_Raised: 2026-06-12 · Status: DECIDED 2026-06-12_

Problem found with the "can only look 2-3 levels below" rule:
Hierarchy is NSM -> RSM -> ASM -> SO -> Distributor. A level-cap would stop an NSM at
ASM. Then "which distributor sold more?" returns nothing — even though it is a fair,
small question.

### DECISION

Do NOT cap by hierarchy level. Cap by **result size**.

- Top-N / ranked / totals → allow at ANY depth (the answer is small).
- Big flat lists, deep down → ask the user to narrow first ("all India, or one region?").

The "2-3 levels" becomes a **default depth**, not a wall:
- Home / dashboard → pre-show only 2-3 levels deep (they did not ask).
- Chat → can go deeper, as top-N or after narrowing (they asked).

This also controls data volume up front, which was the real goal.
Written into the spec: `spec/20-resolution.md` section 5.
