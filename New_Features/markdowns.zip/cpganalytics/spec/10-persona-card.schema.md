# 10 — Persona Card Schema

> **Status:** DRAFT v0.1 (2026-06-11)
> The single, common schema for ALL hierarchy levels. SO, ASM, RSM, NSM, Brand Manager,
> Marketing Manager, Business Analyst are all the SAME shape with different values.

---

## Purpose

A Persona Card is the **vendor-curated, industry-generic blueprint for one role**. It is the
secret sauce: it encodes CPG domain knowledge (hierarchy, what the role watches, how it
disambiguates, what it asks) so a buyer only has to assign users to it. Cards are shipped
and versioned by the vendor; buyers do not normally edit them (see `20-resolution.md`).

## Design rules

- **Common to all levels.** Differences are expressed as field VALUES, never new structure.
- **Semantic, not visual.** No layout/CSS here — see `14-section-grammar.schema.md`.
- **Thin.** `kpis`, `insight_types`, `questions[].intent`, and catalog slots are *references*
  into `12` (metrics), `13` (insight rules), and `11` (catalog). The card names them; it does
  not define their logic or thresholds.
- **Deterministic-safe.** Nothing here produces a metric value or a score.

## What makes one schema cover every level

| Axis that varies by level | Expressed as | Leaf vs top example |
|---|---|---|
| Position in org | `hierarchy.{tree,level,reports_to,manages}` | SO `manages: []` · NSM `manages: [rsm]` |
| Unit of accountability | `scope.operating_grain` + paths | SO `outlet` · NSM `nation` |
| Org tree | `hierarchy.tree` | sales vs marketing |
| What they watch / ask | list contents of `kpis`/`insight_types`/`questions`/`actions` | different members, same keys |

---

## Field table

| Field | Type | Required | Notes |
|---|---|---|---|
| `card_id` | string (snake_case) | yes | stable, vendor-owned, unique |
| `version` | integer | yes | bumped on vendor upgrade |
| `display_name` | string | yes | human label |
| `job_description` | string | yes | plain-English job of this role. Sets the assistant's TOPIC scope: questions inside the job are handled, questions outside are declined. Does NOT control data access — that is RBAC. |
| `hierarchy.tree` | enum `sales\|marketing\|analytics` | yes | which org tree |
| `hierarchy.level` | integer | yes | rank within tree (higher = more senior) |
| `hierarchy.reports_to` | string \| null | yes | `card_id` of manager, `null` at top |
| `hierarchy.manages` | string[] | yes | `card_id`s managed; `[]` for a leaf |
| `scope.operating_grain` | string (dimension) | yes | unit the role owns (`outlet`, `distributor`, `region`, `nation`, `brand`…) |
| `scope.drilldown_path` | string[] | yes | ordered dims the role can go DOWN |
| `scope.rollup_path` | string[] | yes | ordered dims the role rolls UP into (compare/escalate); may be `[]` |
| `scope.default_period` | enum `TODAY\|MTD\|QTD\|YTD` | yes | default time framing |
| `kpis.primary` | string[] (metric ids) | yes | headline KPIs; ids must exist in `12` |
| `kpis.secondary` | string[] (metric ids) | no | supporting KPIs |
| `preferences` | PrefRef[] | yes | catalog overrides this role cares about |
| `preferences[].preference` | string (preference id) | yes | must exist in `11` |
| `preferences[].default` | string | yes | must be one of the preference's `options` in `11` |
| `preferences[].ask_priority` | enum `high\|medium\|never` | yes | drives cold-start selection |
| `insight_types` | string[] (rule ids) | yes | subset of registry `13` shown to this role |
| `questions` | Question[] | yes | curated Ask-Analyst / clarification bank |
| `questions[].id` | string | yes | stable |
| `questions[].text` | string | yes | display text (may contain `{{tokens}}`) |
| `questions[].intent` | string | yes | pre-classified intent id |
| `questions[].entities` | object | no | known entities (metric/dimension/period) |
| `questions[].cube_context` | object | no | measures/dimensions/filters hint for chat fast-path |
| `actions` | Action[] | yes | role-appropriate recommended actions |
| `actions[].id` | string | yes | stable |
| `actions[].label` | string | yes | display verb phrase |
| `actions[].from_insight` | string (rule id) | no | insight type this action maps from |
| `cold_start.ask_preferences` | string[] (preference ids) | yes | subset of `preferences[].preference`, all `ask_priority: high` |
| `cold_start.max_questions` | integer (1–3) | yes | hard cap on cold-start questions |

---

## JSON Schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://cpg-analytics/spec/persona-card.schema.json",
  "title": "PersonaCard",
  "type": "object",
  "additionalProperties": false,
  "required": ["card_id", "version", "display_name", "job_description", "hierarchy", "scope",
               "kpis", "preferences", "insight_types", "questions", "actions", "cold_start"],
  "properties": {
    "card_id":         { "type": "string", "pattern": "^[a-z][a-z0-9_]*$" },
    "version":         { "type": "integer", "minimum": 1 },
    "display_name":    { "type": "string", "minLength": 1 },
    "job_description": { "type": "string", "minLength": 1 },

    "hierarchy": {
      "type": "object",
      "additionalProperties": false,
      "required": ["tree", "level", "reports_to", "manages"],
      "properties": {
        "tree":       { "enum": ["sales", "marketing", "analytics"] },
        "level":      { "type": "integer", "minimum": 1 },
        "reports_to": { "type": ["string", "null"], "pattern": "^[a-z][a-z0-9_]*$" },
        "manages":    { "type": "array", "items": { "type": "string", "pattern": "^[a-z][a-z0-9_]*$" } }
      }
    },

    "scope": {
      "type": "object",
      "additionalProperties": false,
      "required": ["operating_grain", "drilldown_path", "rollup_path", "default_period"],
      "properties": {
        "operating_grain": { "type": "string" },
        "drilldown_path":  { "type": "array", "items": { "type": "string" } },
        "rollup_path":     { "type": "array", "items": { "type": "string" } },
        "default_period":  { "enum": ["TODAY", "MTD", "QTD", "YTD"] }
      }
    },

    "kpis": {
      "type": "object",
      "additionalProperties": false,
      "required": ["primary"],
      "properties": {
        "primary":   { "type": "array", "minItems": 1, "items": { "type": "string" } },
        "secondary": { "type": "array", "items": { "type": "string" } }
      }
    },

    "preferences": {
      "type": "array",
      "items": {
        "type": "object",
        "additionalProperties": false,
        "required": ["preference", "default", "ask_priority"],
        "properties": {
          "preference":   { "type": "string" },
          "default":      { "type": "string" },
          "ask_priority": { "enum": ["high", "medium", "never"] }
        }
      }
    },

    "insight_types": { "type": "array", "items": { "type": "string" } },

    "questions": {
      "type": "array",
      "items": {
        "type": "object",
        "additionalProperties": false,
        "required": ["id", "text", "intent"],
        "properties": {
          "id":           { "type": "string" },
          "text":         { "type": "string" },
          "intent":       { "type": "string" },
          "entities":     { "type": "object" },
          "cube_context": { "type": "object" }
        }
      }
    },

    "actions": {
      "type": "array",
      "items": {
        "type": "object",
        "additionalProperties": false,
        "required": ["id", "label"],
        "properties": {
          "id":           { "type": "string" },
          "label":        { "type": "string" },
          "from_insight": { "type": "string" }
        }
      }
    },

    "cold_start": {
      "type": "object",
      "additionalProperties": false,
      "required": ["ask_preferences", "max_questions"],
      "properties": {
        "ask_preferences": { "type": "array", "items": { "type": "string" } },
        "max_questions": { "type": "integer", "minimum": 1, "maximum": 3 }
      }
    }
  }
}
```

---

## Validation rules (beyond JSON Schema — enforce in CI)

1. Every id in `kpis.primary` / `kpis.secondary` MUST exist in the metric registry (`12`).
2. Every id in `insight_types` MUST exist in the insight-rule registry (`13`).
3. Every `preferences[].preference` MUST exist in the catalog (`11`); its `default` MUST be one of
   that preference's `options`.
4. Every `cold_start.ask_preferences` entry MUST appear in `preferences` with `ask_priority: high`.
5. `len(cold_start.ask_preferences) <= cold_start.max_questions`.
6. `hierarchy.reports_to` and every `hierarchy.manages` id MUST resolve to an existing card_id
   in the SAME `tree` (referential integrity across the persona set).
7. `scope.operating_grain` and all path dims MUST be valid Cube.js dimensions.
8. `job_description` sets TOPIC scope only. It MUST NOT be used to grant or restrict data
   access. RBAC is the only access control (see `20-resolution.md`).
9. Every rule id in `insight_types` SHOULD list the card's `scope.operating_grain` in its
   `applies_to.operating_grain` (or omit `applies_to`). Keeps shown insights grain-appropriate.
10. Every rule id in `insight_types` SHOULD have a matching card action — an `actions[]` entry
    whose `from_insight` equals that rule id — so every shown insight is actionable.

---

## Versioning

- Additive field changes → minor; the schema `version` in this doc bumps.
- Breaking changes (renamed/removed field, tightened enum) → major; authored cards must
  declare the schema version they target and be migrated.
- A card's own `version` is independent — it tracks vendor content upgrades to that role.

---

## Worked example

See `examples/asm.card.yaml` (Area Sales Manager) and `examples/nsm.card.yaml`
(National Sales Manager) — identical shape, different values.
