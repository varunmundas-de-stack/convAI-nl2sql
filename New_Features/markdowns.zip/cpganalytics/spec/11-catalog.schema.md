# 11 — Preference Catalog Schema

> **Status:** DRAFT v0.2 (2026-06-12, rev 2026-06-29)
> One place that defines every preference — a query parameter the system may need to ask or assume.
> Cards only pick a default for each preference. This file says what the preference is and what each
> answer changes.

---

## Purpose

A preference is one query parameter the system needs resolved before it can run, like "Primary or Secondary sales?".

The catalog answers, for each preference:

- What is the question?
- What are the options?
- What does each option change? (which metric, unit, baseline, period, or filter)

We define each preference **once** here. It is industry-generic, so it is the same for every
buyer and every role. The only per-role part is the default, which lives in the card.

This is the idea from our chat: **map everything, default most, ask few.**
The "map everything" part is this file.

## Phase 1 behaviour (decided 2026-06-12)

- We show the options with a default.
- The user confirms at first login.
- The user can change a preference any time. The active session can override it.
- We do NOT learn habits yet (User Model layers 3 + 4 come in a later phase).

## Design rules

- One preference = one entry = one id.
- The preference lives here. The default for a role lives in the persona card.
- Each option says what it maps to. That is how an answer becomes a real query change.
- A preference is always reversible. The user can change it later.

---

## Field table

| Field | Type | Required | Notes |
|---|---|---|---|
| `preference_id` | string (snake_case) | yes | stable id, e.g. `sales_type` |
| `category` | enum (see below) | yes | groups preferences for the UI |
| `question_text` | string | yes | the question to ask if the preference is unknown |
| `options` | Option[] | yes | the choices |
| `options[].value` | string | yes | stable value id, e.g. `primary` |
| `options[].label` | string | yes | text shown to the user |
| `options[].maps_to` | object | yes | what choosing this option sets (see below) |
| `reversible` | boolean | yes | always `true` for now |

**`category` values:** `data_source`, `measure`, `baseline`, `time_framing`, `trend`,
`comparison`, `granularity`, `channel`, `brand`, `output_style`.

**`maps_to` keys** (all optional; use the ones that fit the preference):

| Key | Means | Allowed values |
|---|---|---|
| `measure` | use this metric id as the main measure | a metric id from `12` |
| `unit` | how to count | `pcs_packs` \| `volume` \| `value` |
| `comparison_metric` | which metric id to compare against | a metric id from `12` |
| `comparison_period` | which period to compare against | `previous_month` \| `previous_quarter` \| `smly` |
| `baseline_window` | history window for averages/anomaly | `l3m` \| `l6m` \| `l13m` |
| `trend_grain` | bucket size for trend charts | `day` \| `week` \| `month` |
| `dimension` | which dimension to drill into | a Cube.js dimension |
| `filter` | a filter to apply | object, e.g. `{period: MTD}` |

---

## JSON Schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://cpg-analytics/spec/catalog.schema.json",
  "title": "PreferenceCatalog",
  "type": "array",
  "items": {
    "type": "object",
    "additionalProperties": false,
    "required": ["preference_id", "category", "question_text", "options", "reversible"],
    "properties": {
      "preference_id":  { "type": "string", "pattern": "^[a-z][a-z0-9_]*$" },
      "category":      { "enum": ["data_source", "measure", "baseline", "time_framing",
                                  "trend", "comparison", "granularity", "channel",
                                  "brand", "output_style"] },
      "question_text": { "type": "string", "minLength": 1 },
      "reversible":    { "type": "boolean" },
      "options": {
        "type": "array",
        "minItems": 2,
        "items": {
          "type": "object",
          "additionalProperties": false,
          "required": ["value", "label", "maps_to"],
          "properties": {
            "value": { "type": "string", "pattern": "^[a-z][a-z0-9_]*$" },
            "label": { "type": "string", "minLength": 1 },
            "maps_to": {
              "type": "object",
              "additionalProperties": false,
              "properties": {
                "measure":           { "type": "string" },
                "unit":              { "enum": ["pcs_packs", "volume", "value"] },
                "comparison_metric": { "type": "string" },
                "comparison_period": { "enum": ["previous_month", "previous_quarter", "smly"] },
                "baseline_window":   { "enum": ["l3m", "l6m", "l13m"] },
                "trend_grain":       { "enum": ["day", "week", "month"] },
                "dimension":         { "type": "string" },
                "filter":            { "type": "object" }
              }
            }
          }
        }
      }
    }
  }
}
```

---

## Validation rules (check in CI)

1. Every `preference_id` is unique.
2. Every `options[].value` is unique inside its preference.
3. Any `measure` or `comparison_metric` in `maps_to` must exist in the metric registry (`12`).
4. Any `dimension` in `maps_to` must be a valid Cube.js dimension.
5. A card's `preferences[].preference` must match an existing `preference_id` in this catalog (checked in `10`).

---

## Versioning

- Add a new preference or option → fine, no break.
- Remove a preference/option, or change a `value` → breaking. Cards using it must be updated.

---

## Worked example

See `examples/catalog.yaml`. One preference:

```yaml
- preference_id: sales_type
  category: data_source
  question_text: "Which sales view do you usually work with?"
  reversible: true
  options:
    - value: secondary
      label: "Secondary"
      maps_to: { measure: secondary_net_sales }
    - value: primary
      label: "Primary"
      maps_to: { measure: net_sales }
```
