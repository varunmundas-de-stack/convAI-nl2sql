# CPG Analytics — Product & UX Discussion

> Working document for our product/UX discussion.
> We discuss here freely; at each milestone we snapshot with a date/time stamp.

---

## Status

- **Mode:** UX / product discussion (no code yet)
- **Started:** 2026-06-01 16:15 IST
- **Last updated:** 2026-06-08 11:26 IST

---

## Governing Principle (applies to everything below)

**Facts are deterministic. Language is intelligent.**
Cube.js + SQL + Python compute every number, ranking, threshold, and score.
The LLM only narrates, explains, suggests wording, classifies intent, and converses.
The LLM never invents metrics, never bypasses RBAC, never presents a "possible reason"
as proven.

---

## Topic 1 — Knowing the User & Building Memory

### The core reframe: two profiles, never confused

There is no single "image of the user." There are two profiles on opposite sides of the
governing principle:

- **Given identity** — role, geography scope, RBAC. Deterministic, from login/HR.
  We **never infer or learn** this. (Inferring scope could leak data the user shouldn't see.)
- **Learned model** — preferences, habits, defaults, recurring questions. Probabilistic,
  from interaction. Always correctable, always reversible.

### The seed problem (from the chat screenshot)

User asks "How is my sales doing today" → system asks "Primary or Secondary?".
That's fine the *first* time. By the *tenth* time, if he always picks Primary, we should
not be asking anymore. The lifecycle **ask → default → assume** is the whole game.

### The internal "image of the user" (memory model — 5 layers)

```text
User Model  (the internal image)
│
├── 1. Identity Layer        [given · deterministic · never learned]
│   ├── user_id, name, role
│   ├── geo / brand / channel scope
│   └── RBAC permissions
│
├── 2. Preference Layer      [declared · explicit · high trust]
│   ├── sales_type: Primary
│   ├── default_comparison: vs_target
│   ├── output_style: concise
│   └── each item: {value, source, confidence, last_confirmed}
│
├── 3. Behavioral Layer      [observed · implicit · probabilistic]
│   ├── top_intents:   [target_gap, distributor_risk]
│   ├── focus_entities:[zone:South, distributor:3]
│   ├── time_habits:   prefers MoM
│   ├── cadence:       logs in ~9am daily
│   └── each item: {value, evidence_count, confidence, decay}
│
├── 4. Episodic Layer        [history · what was asked/answered]
│   ├── recent questions + resolved intents
│   ├── insights viewed / ignored / pinned
│   └── actions marked useful
│
└── 5. Working Layer         [session · transient]
    ├── current filters / period
    ├── active thread + last entity in focus
    └── carried context for follow-ups ("which ones?")
```

### Subsequent interactions — the clarification lifecycle

```text
Clarification lifecycle (per ambiguous slot, e.g. Primary/Secondary)
├── Stage 1  ASK        → n=0, no signal → full question
├── Stage 2  DEFAULT    → some signal → pre-select last choice,
│                          still show the toggle ("Primary ▾")
└── Stage 3  ASSUME     → strong, consistent signal → answer silently,
                           show "(Primary · change)"
Correction at any stage → demote confidence, re-learn
```

### Governance guardrails (critical)

- NEVER infer RBAC / scope from behavior.
- Preferences are reversible + visible ("why am I seeing this?").
- Confidence decays if habits change (recency-weighted).
- Learned ≠ locked: always offer the override.

---

## Topic 2 — Make Cold Start Easy: Curated Catalog ("map everything, default most, ask few")

User's idea: don't clarify reactively mid-conversation (repetitive, annoying). Instead
pre-curate a **catalog of every disambiguation that could ever come up**, map each to the
metrics/values it resolves, then at start ask only the 2-3 highest-value ones. Everything
else gets a silent default the catalog already knows.

### The Curated Question / Preference Catalog

```text
Preference Catalog  (curated once, reused for every user)
│
├── Each entry = one "slot" the system might need resolved
│   ├── slot_id            e.g. sales_type
│   ├── question_text      "Which sales view do you usually work with?"
│   ├── options            [Primary, Secondary]
│   ├── maps_to            ← THE KEY: what this answer controls
│   │   ├── measures       primary_net_sales | secondary_net_sales
│   │   ├── fact_table     sales_fact | secondary_sales_fact
│   │   └── default_unit   value | units
│   ├── default_by_role    {SO: Secondary, ASM: Secondary, NSM: Primary}
│   ├── ask_priority       high | medium | never-ask (just default)
│   ├── resolves_downstream which other slots this answer cascades into
│   └── reversible         true (always shown as a toggle later)
│
├── Slot categories (curate broadly here)
│   ├── Data source        Primary vs Secondary · value vs volume
│   ├── Time framing        MTD · today · vs last month · vs LY
│   ├── Comparison basis     vs target · vs last period · vs LY
│   ├── Granularity focus    zone · distributor · SKU · channel · outlet
│   ├── KPI priority         net sales · growth% · target ach% · gap value
│   ├── Channel focus        General Trade · Modern Trade · E-comm
│   ├── Brand/category focus which brands he tracks
│   └── Output style         concise · detailed · table · manager-summary
│
└── Feeds BOTH
    ├── Cold-start onboarding  (ask the few high-priority ones)
    └── In-chat fallback        (if a slot is ever still unknown, ask then)
```

### Cold-start strategy — ask MINIMAL

```text
Cold Start
├── Step 1: Resolve everything we can SILENTLY (role defaults + scope)
├── Step 2: Score remaining ambiguity per slot
│           ask_score = ambiguity × impact × frequency
├── Step 3: Ask ONLY top 2-3 by ask_score
│           prefer slots that CASCADE; bundle into one short card (not a quiz)
├── Step 4: Everything else = assume + reveal as editable chips
│           "MTD · South Zone · vs Target ▾"
└── Step 5: Write resolved slots to Preference Layer
            asked → confidence high (declared)
            defaulted → confidence medium (role prior)
```

### Starter catalog (concrete — "map it with metrics and values")

| slot | question (asked only if high-priority) | options → maps to | role default | ask? |
|------|------|------|------|------|
| `sales_type` | "Primary or secondary sales?" | Primary→`primary_net_sales` / Secondary→`secondary_net_sales` | SO/ASM: Secondary · NSM: Primary | **ask** |
| `measure_unit` | "Track by value or volume?" | Value→`net_sales` / Units→`net_units` | Value | **ask** |
| `comparison_basis` | "Against target or last month?" | →`target_achievement_pct` / `sales_growth_pct` | vs target | maybe |
| `time_framing` | — | →`period` dimension | MTD | never-ask |
| `granularity_focus` | — | →primary drilldown dim | RSM→zone, ASM→distributor | never-ask |
| `channel_focus` | — | →`channel` filter | All / by scope | never-ask |

**Cap cold-start at 2-3 questions, hard limit.** Everything else defaults.

---

## Topic 3 — Persona Cards (THE SECRET SAUCE / business model)

We sell the app to CPG companies. The product ships with **vendor-curated persona cards**
(SO, ASM, RSM, NSM, Brand Manager, Marketing Manager, Business Analyst). Using deep CPG
domain knowledge — the standard **sales hierarchy** and what each role cares about — each
card pre-encodes the KPIs, insight types, question bank, and the entire preference catalog
with industry-correct defaults.

The buyer does almost no setup: they **assign each employee to a persona** and that person
instantly inherits a fully-loaded, correct experience. **Cold start is never cold** — the
persona card IS the warm prior. The Preference Catalog from Topic 2 is not built per-buyer;
it is pre-loaded inside the persona card.

### What's inside a Persona Card (vendor-curated)

```text
Persona Card  (e.g. "Area Sales Manager")   ← shipped with the product
│
├── Identity blueprint  (what this role IS in CPG)
│   ├── avatar_id: asm
│   ├── hierarchy_position: reports_to → RSM ; manages → SOs
│   ├── typical_scope_shape: a set of distributors in one area
│   └── responsibility: secondary sales, coverage, distributor health
│
├── KPI set  (what this role watches)
│   ├── primary: secondary_net_sales, target_achievement_pct, coverage_pct
│   └── secondary: distributor_stock_days, inactive_outlet_count
│
├── Pre-loaded Preference Catalog  (defaults, already mapped)
│   ├── sales_type = Secondary · measure_unit = Value
│   ├── granularity = distributor · comparison = vs target
│   └── every slot pre-filled with the industry-correct value
│
├── Insight types that matter to this role
│   └── distributor_underperformance · outlet_coverage_drop ·
│       stockout_risk · target_gap
│
├── Curated questions  (Ask Analyst + clarification bank)
│   └── each pre-tagged with intent + entities + cube context
│
├── Recommended action style  (role-appropriate verbs)
│   └── "Call distributor" · "Check stock" · "Fix coverage gap"
│
└── Minimal ask-set  (what to confirm at first login)
    └── often ZERO — the card already knows; just reveal + let him edit
```

### Three-tier resolution (how a real user is assembled)

```text
How a real user's experience is assembled
│
├── Tier 1: PERSONA CARD       [vendor-curated · industry knowledge · THE SAUCE]
│   └── KPIs, defaults, insights, questions, hierarchy
│       (same for every ASM at every company that buys)
│
├── Tier 2: TENANT BINDING     [buyer-configured · their specifics]
│   ├── company assigns user → persona ("Ravi is an ASM")
│   ├── inject THEIR real data: actual brands, regions, distributors
│   ├── RBAC / scope from their org data (deterministic, never inferred)
│   └── optional overrides: their thresholds, target definitions
│
└── Tier 3: INDIVIDUAL MODEL   [learned · per-person · over time]
    ├── declared tweaks (prefers units, not value)
    ├── observed habits (always drills into Distributor 3)
    └── personalizes WITHIN the persona, never breaks RBAC
```

Resolution order: **Persona Card → Tenant Binding → Individual Model.** Each tier overrides
the one above, but only within what's allowed. A user is "an ASM persona, at Company X,
who happens to be Ravi."

### Consequences

- **Cold start basically disappears** — persona defaults make the 2-3 questions optional.
- **Hierarchy is part of the sauce** — card knows ASM→RSM→NSM, enabling scope roll-up,
  peer comparison, and escalation ("this is really an RSM-level problem").

### Open decisions

1. **Persona/tenant boundary — needs a hard line.**
   - In the card (vendor IP, industry-generic): KPIs, insight types, question bank,
     default preferences, hierarchy.
   - Tenant data (their business): brands, regions, distributors, thresholds, RBAC.
   - Getting this boundary right is what lets the same card sell to 50 companies without
     leaking one company's setup into another.
2. **Can a buyer customize a persona card?** Three models:
   - (a) locked — buyer only assigns users.
   - (b) clone-and-tweak — buyer forks the card, adjusts thresholds/questions.
   - (c) layered overrides — vendor card stays canonical, buyer adds a thin override layer.
   - **Leaning (c):** keeps vendor IP updatable (ship a better ASM card next quarter,
     everyone benefits) while letting buyers tune.
3. **Cold-start ask aggressiveness** — how boldly to move from "ask" to "assume" (trust vs friction).
4. **Learned model: per-user only, or also a role-level prior that feeds back?**

---

## Milestones

### Milestone 1 — Memory, Curated Catalog & Persona-Card Model — 2026-06-08 11:26 IST

Established the foundational UX/product model for knowing the user:

1. **Two profiles, never confused:** given identity (deterministic, never learned) vs
   learned model (probabilistic, reversible). 5-layer User Model (Identity / Preference /
   Behavioral / Episodic / Working).
2. **Curated Catalog approach:** map every disambiguation slot to metrics/values up front;
   default most from role; ask a hard-capped 2-3 questions at cold start. Clarification
   lifecycle: ask → default → assume.
3. **Persona Cards = the secret sauce:** vendor pre-curates per-role cards (KPIs, insight
   types, question bank, pre-loaded preference catalog, hierarchy) from CPG domain
   knowledge. Buyers just assign users to personas; cold start is never cold.
4. **Three-tier resolution:** Persona Card → Tenant Binding → Individual Model.

Open decisions carried forward: persona/tenant boundary, persona customization model
(leaning layered overrides), ask aggressiveness, role-level prior feedback.

### Milestone 2 — Moved to Spec Package; Common Persona Card schema drafted — 2026-06-11 13:47 IST

Decided HOW to progress for a coding team: stop producing discussion trees, produce a
versioned **`spec/` package** of contracts (typed fields + JSON Schema + worked examples +
CI validation). `ux.md` = thinking; `spec/` = what the team builds against.

Locked 4 schema-level decisions (v0.1, reversible):
1. One schema per concept, COMMON across all hierarchy levels (differences = field values).
2. Persona Cards are SEMANTIC; layout is a separate common section-grammar.
3. Cards are THIN; they REFERENCE central registries (metrics `12`, insight rules `13`).
4. Catalog slot definitions are SHARED (`11`); cards carry only {slot, default, ask_priority}.

Created so far:
- `spec/README.md` (index, conventions, locked decisions, glossary, build order)
- `spec/10-persona-card.schema.md` (the anchor — full field table + JSON Schema + validation rules)
- `spec/examples/asm.card.yaml` + `spec/examples/nsm.card.yaml` (same shape, different values — proves level-agnosticism)

Still TODO in spec package: `00-architecture.md`, `11-catalog.schema.md`,
`12-metric-registry.md`, `13-insight-rule.schema.md`, `14-section-grammar.schema.md`,
`20-resolution.md`, `examples/catalog.yaml`.

### Milestone 3 — Full spec package complete (DRAFT v0.1) — 2026-06-22 12:06 IST

All spec files are now written and consistent. Ready for team review.

Spec files:
- `00-architecture.md` — big-picture on-ramp.
- `10-persona-card.schema.md` — common card schema (+ `job_description`).
- `11-catalog.schema.md` — preference/question slots (v0.2, real CPG slots).
- `12-metric-registry.md` — metric -> Cube.js measure.
- `13-insight-rule.schema.md` — deterministic risk/opportunity/anomaly/driver rules.
- `14-section-grammar.schema.md` — home page layout grammar.
- `20-resolution.md` — runtime: 3 tiers, RBAC, scope check, geo depth, freshness.

Examples (all cross-referenced and CI-validatable):
- `asm.card.yaml`, `nsm.card.yaml` — same shape, different values, with job descriptions.
- `catalog.yaml` — 9 real slots (sales_type, sales_metric, stock_metric, time_period,
  history_sales_avg, sales_trend, comparison_period, channel_focus, output_style).
- `metric-registry.yaml` — 12 metrics.
- `insight-rules.yaml` — 10 rules across all four types (7 risk, 1 anomaly, 1 opportunity, 1 driver).
- `nsm.home.yaml` — the NSM home page layout.

Also decided: Q2 (geo depth) — cap by result size, not hierarchy level. See open-questions.md.

Open for the discussion that follows: tenant override model detail, scoring weights,
question-bank as a shared library vs on-card, the LLM guardrail/validation design,
and which persona to build first.

### Milestone 4 — Spec consistency pass — 2026-06-29

Full cross-file audit of the spec package, then fixed every discrepancy found:

1. **Insight-rule count.** Docs claimed 11; the file has 10 (7 risk, 1 anomaly, 1 opportunity,
   1 driver). Corrected the count in `ux.md` and `PROJECT_CONTEXT.md`.
2. **ASM operating_grain.** Was `distributor`, which appeared in *no* rule's `applies_to`
   (so the ASM matched none of its own insight types). Corrected to `area` — matches the role
   name and makes all four ASM insight types grain-consistent. `rollup_path` trimmed `[area,
   region]`→`[region]` (a role no longer rolls up into its own grain).
3. **Actions had no home / two sources of truth.** Rules and cards both encoded insight→action,
   and several rule-referenced action ids were defined nowhere. Resolved by making the **persona
   card authoritative**: `card.actions[].from_insight` is the role-appropriate mapping the user
   sees; `rule.actions` (13) are now **advisory defaults** (field made optional). Added card
   actions so every authored `insight_type` has a matching role action (ASM:
   `review_weak_distributors`; NSM: `review_at_risk_distributors`, `review_sku_mix`,
   `review_stock_cover`). `14` clarified that `action_list` resolves via the card.
4. **Smaller gaps.** Added `chart.trend_grain` to the section grammar (optional; defaults to the
   `sales_trend` preference); defined the priority buckets `critical|high|medium|low` in `13`
   (used by `14` `filters.priority`); clarified period precedence in `20` (`scope.default_period`
   seeds, the `time_period` slot is source of truth); added two card↔rule CI checks to `10`
   (grain-appropriate insights; every insight actionable).

Known, expected gap (not a defect): only `asm` + `nsm` of the 7 personas are authored, so
referential checks that point at unauthored cards (`rsm`, `so`) and their actions stay open
until those cards ship.
