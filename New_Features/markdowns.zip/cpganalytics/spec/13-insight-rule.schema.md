# 13 — Insight Rule Registry

> **Status:** DRAFT v0.1 (2026-06-12)
> The rules that find risks, opportunities, anomalies, and drivers in the data.
> Each rule is a deterministic check. Cards only name the rule ids they show.

---

## Purpose

An insight is a fact worth attention, like "target achievement is below 80%".

A rule defines:

- When does this insight fire? (the trigger)
- How bad / how big is it? (the impact)
- Where do we look for the likely reason? (the evidence)
- What can the user do about it? (the actions)

Rules are deterministic. They run on Cube.js numbers. The LLM only writes the words
around the result. The LLM never decides if a rule fired.

## Design rules

- One rule = one entry = one id.
- The rule lives here, once. Cards just list which rule ids they show.
- Thresholds live in the rule as a default. A tenant may override them (see `20`).
- Confidence and priority are computed by the engine, not by the LLM (see below).
- `actions` here are ADVISORY defaults. The persona card (`10`) owns the role-appropriate
  insight→action mapping via `actions[].from_insight` — that is what a user actually sees.

---

## Insight types

| type | meaning |
|---|---|
| `risk` | something going wrong (target miss, decline, stockout) |
| `opportunity` | something to gain (fast SKU, under-distributed product) |
| `anomaly` | an odd jump or drop versus the normal pattern |
| `driver` | what is moving a number (volume, price, mix, distribution) |

## Trigger kinds

A rule fires using one of three trigger kinds.

```text
threshold  → metric compared to a fixed number      (e.g. target_ach < 80)
variance   → metric compared to a baseline period   (e.g. sales down >10% vs last month)
anomaly    → metric far from its history average     (e.g. z-score > 2 vs L3M avg)
```

---

## Field table

| Field | Type | Required | Notes |
|---|---|---|---|
| `rule_id` | string (snake_case) | yes | stable id, e.g. `target_gap` |
| `type` | enum `risk\|opportunity\|anomaly\|driver` | yes | the insight type |
| `title` | string | yes | short plain title shown to user |
| `trigger.kind` | enum `threshold\|variance\|anomaly` | yes | how the rule fires |
| `trigger.metric` | string (metric id) | yes | the metric being checked; must exist in `12` |
| `trigger.operator` | enum `lt\|lte\|gt\|gte\|eq\|ne` | threshold only | comparison vs `value` |
| `trigger.value` | number | threshold only | the fixed number |
| `trigger.baseline` | enum `previous_month\|previous_quarter\|smly\|target` | variance only | what to compare against |
| `trigger.direction` | enum `up\|down` | variance only | which way of change matters |
| `trigger.min_change_pct` | number | variance only | minimum % change to fire |
| `trigger.history_window` | enum `l3m\|l6m\|l13m` | anomaly only | the history average to use |
| `trigger.z_threshold` | number | anomaly only | how far from normal to fire |
| `breakdown` | string[] | yes | dims to slice to find where it is worst |
| `impact.metric` | string (metric id) | yes | metric that sizes the impact (for priority) |
| `evidence` | string[] | no | other rule ids to check for the likely reason |
| `actions` | string[] | no | ADVISORY default action ids. The authoritative, role-appropriate action a user sees comes from the persona card (`10`) via `actions[].from_insight`. |
| `applies_to.operating_grain` | string[] | no | which role grains this rule is relevant for |

---

## JSON Schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://cpg-analytics/spec/insight-rule.schema.json",
  "title": "InsightRuleRegistry",
  "type": "array",
  "items": {
    "type": "object",
    "additionalProperties": false,
    "required": ["rule_id", "type", "title", "trigger", "breakdown", "impact"],
    "properties": {
      "rule_id": { "type": "string", "pattern": "^[a-z][a-z0-9_]*$" },
      "type":    { "enum": ["risk", "opportunity", "anomaly", "driver"] },
      "title":   { "type": "string", "minLength": 1 },

      "trigger": {
        "type": "object",
        "additionalProperties": false,
        "required": ["kind", "metric"],
        "properties": {
          "kind":           { "enum": ["threshold", "variance", "anomaly"] },
          "metric":         { "type": "string" },
          "operator":       { "enum": ["lt", "lte", "gt", "gte", "eq", "ne"] },
          "value":          { "type": "number" },
          "baseline":       { "enum": ["previous_month", "previous_quarter", "smly", "target"] },
          "direction":      { "enum": ["up", "down"] },
          "min_change_pct": { "type": "number" },
          "history_window": { "enum": ["l3m", "l6m", "l13m"] },
          "z_threshold":    { "type": "number" }
        },
        "allOf": [
          { "if": { "properties": { "kind": { "const": "threshold" } } },
            "then": { "required": ["operator", "value"] } },
          { "if": { "properties": { "kind": { "const": "variance" } } },
            "then": { "required": ["baseline", "direction", "min_change_pct"] } },
          { "if": { "properties": { "kind": { "const": "anomaly" } } },
            "then": { "required": ["history_window", "z_threshold"] } }
        ]
      },

      "breakdown": { "type": "array", "items": { "type": "string" } },
      "impact": {
        "type": "object",
        "additionalProperties": false,
        "required": ["metric"],
        "properties": { "metric": { "type": "string" } }
      },
      "evidence": { "type": "array", "items": { "type": "string" } },
      "actions":  { "type": "array", "items": { "type": "string" } },
      "applies_to": {
        "type": "object",
        "additionalProperties": false,
        "properties": { "operating_grain": { "type": "array", "items": { "type": "string" } } }
      }
    }
  }
}
```

---

## Confidence and priority (engine computes both — never the LLM)

The rule says *what* to check. The engine then scores the result:

```text
Confidence (how reliable is this insight?)
├── data completeness   (are all needed metrics + periods present?)
├── evidence strength   (does the signal show across breakdown dims?)
└── stability           (is it more than one-day noise vs the baseline?)

Priority (how important is it to act?)
├── impact value        (from impact.metric)
├── urgency             (month-end near? stockout active now?)
├── scope               (national vs one outlet)
└── role relevance      (is it in this role's job + grain?)
```

The engine maps the priority score into buckets **`critical | high | medium | low`**
(these are the values the home layout filters on via `filters.priority` in `14`).

Weights for these are engine config (a tenant may tune them — see `20`).
The LLM may explain a score in words. It must never set the number.

---

## Validation rules (check in CI)

1. Every `rule_id` is unique.
2. `trigger.metric` and `impact.metric` exist in the metric registry (`12`).
3. Every id in `evidence` is an existing `rule_id`.
4. `actions` are advisory. Every id SHOULD be defined on at least one persona card (`10`);
   what a user sees is resolved from THEIR card's `actions[].from_insight`. (No separate action map.)
5. `breakdown` and `applies_to.operating_grain` dims are valid Cube.js dimensions.
6. Trigger fields match the `kind` (enforced by the JSON Schema `allOf`).

---

## Worked example

See `examples/insight-rules.yaml`. One rule:

```yaml
- rule_id: target_gap
  type: risk
  title: "Target achievement is below expected level"
  trigger:
    kind: threshold
    metric: target_achievement_pct
    operator: lt
    value: 80
  breakdown: [region, distributor, sku]
  impact:
    metric: sales_gap_value
  evidence: [distributor_underperformance, outlet_coverage_drop, stockout_risk]
  actions: [analyze_target_gap, review_weak_distributors]   # advisory; card decides per role
  applies_to:
    operating_grain: [nation, region, area]
```
